1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/42879de7b8087bc9.js"],"ViewportBoundary"]
4:I[97367,["/_next/static/chunks/42879de7b8087bc9.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
:HL["/_next/static/chunks/ec764c2bc7ab75db.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.29207c2f.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.3b6cae6d.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"buildId":"VAs3r7MskwkJ9Tx4x_XSu","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"head":["$","$1","h",{"children":[null,["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isHeadPartial":false,"staleTime":300}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
6:[["$","title","0",{"children":"ميزان العدالة - منصة المحامين الذكية"}],["$","meta","1",{"name":"description","content":"منصة إدارة مكتب المحاماة المتكاملة"}],["$","meta","2",{"name":"mobile-web-app-capable","content":"yes"}],["$","meta","3",{"name":"apple-mobile-web-app-title","content":"ميزان"}],["$","meta","4",{"name":"apple-mobile-web-app-status-bar-style","content":"black-translucent"}]]
