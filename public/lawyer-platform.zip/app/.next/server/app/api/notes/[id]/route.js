var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notes/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__7756f523._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_notes_[id]_route_actions_c2418725.js")
R.m(35954)
module.exports=R.m(35954).exports
