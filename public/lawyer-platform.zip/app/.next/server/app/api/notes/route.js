var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notes/route.js")
R.c("server/chunks/[root-of-the-server]__cd96cac0._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_zod_v3_external_d1e61c8a.js")
R.c("server/chunks/_next-internal_server_app_api_notes_route_actions_4ad6f471.js")
R.m(82952)
module.exports=R.m(82952).exports
