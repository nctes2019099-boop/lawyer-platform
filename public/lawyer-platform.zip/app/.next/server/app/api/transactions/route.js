var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/transactions/route.js")
R.c("server/chunks/[root-of-the-server]__d0480f62._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_zod_v3_external_d1e61c8a.js")
R.c("server/chunks/_next-internal_server_app_api_transactions_route_actions_73a9eae1.js")
R.m(98683)
module.exports=R.m(98683).exports
