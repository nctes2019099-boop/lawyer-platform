var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/transactions/stats/route.js")
R.c("server/chunks/[root-of-the-server]__beb16752._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_transactions_stats_route_actions_ff6ddad2.js")
R.m(15084)
module.exports=R.m(15084).exports
