var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/subscriptions/current/route.js")
R.c("server/chunks/[root-of-the-server]__121662c4._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_subscriptions_current_route_actions_465b886e.js")
R.m(48130)
module.exports=R.m(48130).exports
