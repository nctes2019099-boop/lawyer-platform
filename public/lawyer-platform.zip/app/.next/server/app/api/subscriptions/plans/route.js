var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/subscriptions/plans/route.js")
R.c("server/chunks/[root-of-the-server]__269b976c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_subscriptions_plans_route_actions_85d6e792.js")
R.m(18605)
module.exports=R.m(18605).exports
