var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/subscriptions/create-payment/route.js")
R.c("server/chunks/[root-of-the-server]__3110bfbb._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/ce889_server_app_api_subscriptions_create-payment_route_actions_94cdae84.js")
R.m(65365)
module.exports=R.m(65365).exports
