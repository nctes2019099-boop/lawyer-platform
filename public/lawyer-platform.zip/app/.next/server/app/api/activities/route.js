var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/activities/route.js")
R.c("server/chunks/[root-of-the-server]__7a7d2bbc._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_activities_route_actions_030944b4.js")
R.m(65177)
module.exports=R.m(65177).exports
