var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/laws/route.js")
R.c("server/chunks/[root-of-the-server]__fcf0ea16._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_laws_route_actions_7a9394f0.js")
R.m(74452)
module.exports=R.m(74452).exports
