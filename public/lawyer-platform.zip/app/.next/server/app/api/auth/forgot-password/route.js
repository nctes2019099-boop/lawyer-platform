var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/forgot-password/route.js")
R.c("server/chunks/[root-of-the-server]__752ae23a._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_zod_v3_external_d1e61c8a.js")
R.c("server/chunks/_next-internal_server_app_api_auth_forgot-password_route_actions_ada86dd3.js")
R.m(69157)
module.exports=R.m(69157).exports
