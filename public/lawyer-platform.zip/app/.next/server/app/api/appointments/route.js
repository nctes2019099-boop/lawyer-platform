var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/appointments/route.js")
R.c("server/chunks/[root-of-the-server]__52e77ac3._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_zod_v3_external_d1e61c8a.js")
R.c("server/chunks/_next-internal_server_app_api_appointments_route_actions_5e333b24.js")
R.m(22536)
module.exports=R.m(22536).exports
