var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/appointments/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__4e565e79._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_appointments_[id]_route_actions_d5462149.js")
R.m(53959)
module.exports=R.m(53959).exports
