var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/history/route.js")
R.c("server/chunks/[root-of-the-server]__a7b82129._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_history_route_actions_b8afa86a.js")
R.m(91117)
module.exports=R.m(91117).exports
