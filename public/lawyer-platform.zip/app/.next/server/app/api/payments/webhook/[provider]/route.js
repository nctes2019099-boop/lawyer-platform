var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/webhook/[provider]/route.js")
R.c("server/chunks/[root-of-the-server]__8899832e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_webhook_[provider]_route_actions_b248222f.js")
R.m(98935)
module.exports=R.m(98935).exports
