var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/petitions/route.js")
R.c("server/chunks/[root-of-the-server]__91b7a4e6._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_zod_v3_external_d1e61c8a.js")
R.c("server/chunks/_next-internal_server_app_api_petitions_route_actions_a27f7a6a.js")
R.m(15088)
module.exports=R.m(15088).exports
