var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__d9e9745a._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_clients_[id]_route_actions_3b263a6d.js")
R.m(98814)
module.exports=R.m(98814).exports
