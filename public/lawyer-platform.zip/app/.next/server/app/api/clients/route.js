var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/clients/route.js")
R.c("server/chunks/[root-of-the-server]__9fcb6b81._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_zod_v3_external_d1e61c8a.js")
R.c("server/chunks/_next-internal_server_app_api_clients_route_actions_cf8c8248.js")
R.m(56913)
module.exports=R.m(56913).exports
