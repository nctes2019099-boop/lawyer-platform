var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cases/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__15d7a027._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_cases_[id]_route_actions_578d77f0.js")
R.m(32650)
module.exports=R.m(32650).exports
