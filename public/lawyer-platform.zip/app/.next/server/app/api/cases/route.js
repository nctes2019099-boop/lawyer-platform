var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cases/route.js")
R.c("server/chunks/[root-of-the-server]__8af8a46e._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_zod_v3_external_d1e61c8a.js")
R.c("server/chunks/_next-internal_server_app_api_cases_route_actions_76363a14.js")
R.m(51971)
module.exports=R.m(51971).exports
