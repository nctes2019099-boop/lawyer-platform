var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/route.js")
R.c("server/chunks/[root-of-the-server]__5b1f6d99._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_zod_v3_external_d1e61c8a.js")
R.c("server/chunks/_next-internal_server_app_api_documents_route_actions_c8dfb15d.js")
R.m(92792)
module.exports=R.m(92792).exports
