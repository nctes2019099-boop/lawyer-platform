var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/audit/route.js")
R.c("server/chunks/[root-of-the-server]__52363ab5._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_audit_route_actions_9d92fa80.js")
R.m(59999)
module.exports=R.m(59999).exports
