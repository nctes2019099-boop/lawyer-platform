var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__0150a2c4._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_route_actions_850cb780.js")
R.m(94483)
module.exports=R.m(94483).exports
