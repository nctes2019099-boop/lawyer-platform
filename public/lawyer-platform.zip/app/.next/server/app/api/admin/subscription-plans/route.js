var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/subscription-plans/route.js")
R.c("server/chunks/[root-of-the-server]__80f340dc._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_subscription-plans_route_actions_81616db1.js")
R.m(80382)
module.exports=R.m(80382).exports
