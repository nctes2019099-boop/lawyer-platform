var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/payments/route.js")
R.c("server/chunks/[root-of-the-server]__108c63e3._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_payments_route_actions_fca5d9ff.js")
R.m(15755)
module.exports=R.m(15755).exports
