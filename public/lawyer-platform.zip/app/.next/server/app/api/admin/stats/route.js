var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/stats/route.js")
R.c("server/chunks/[root-of-the-server]__000ec0ad._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c564325b._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_stats_route_actions_05832952.js")
R.m(2068)
module.exports=R.m(2068).exports
