module.exports=[30382,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_petitions_route_actions_a27f7a6a.js.map