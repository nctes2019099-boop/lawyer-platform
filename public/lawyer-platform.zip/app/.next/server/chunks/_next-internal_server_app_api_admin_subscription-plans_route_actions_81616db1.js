module.exports=[86056,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_subscription-plans_route_actions_81616db1.js.map