module.exports=[84099,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_laws_route_actions_7a9394f0.js.map