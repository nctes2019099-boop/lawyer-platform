module.exports=[98026,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payments_webhook_%5Bprovider%5D_route_actions_b248222f.js.map